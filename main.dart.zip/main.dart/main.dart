import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(WeddingOrderAdapter());
  await Hive.openBox<WeddingOrder>('wedding_orders');
  runApp(MyApp());
}

@HiveType(typeId: 0)
class WeddingOrder {
  @HiveField(0)
  final String brideName;

  @HiveField(1)
  final String fatherName;

  @HiveField(2)
  final String surname;

  @HiveField(3)
  final double price;

  @HiveField(4)
  final String serviceDetails;

  @HiveField(5)
  final String contactNumbers;

  @HiveField(6)
  final String paymentMethod;

  @HiveField(7)
  final double paidAmount;

  @HiveField(8)
  final DateTime date;

  WeddingOrder({
    required this.brideName,
    required this.fatherName,
    required this.surname,
    required this.price,
    required this.serviceDetails,
    required this.contactNumbers,
    required this.paymentMethod,
    required this.paidAmount,
    required this.date,
  });

  bool get isPaidFull => paidAmount >= price;
}

class WeddingOrderAdapter extends TypeAdapter<WeddingOrder> {
  @override
  final int typeId = 0;

  @override
  WeddingOrder read(BinaryReader reader) {
    return WeddingOrder(
      brideName: reader.read(),
      fatherName: reader.read(),
      surname: reader.read(),
      price: reader.read(),
      serviceDetails: reader.read(),
      contactNumbers: reader.read(),
      paymentMethod: reader.read(),
      paidAmount: reader.read(),
      date: reader.read(),
    );
  }

  @override
  void write(BinaryWriter writer, WeddingOrder obj) {
    writer.write(obj.brideName);
    writer.write(obj.fatherName);
    writer.write(obj.surname);
    writer.write(obj.price);
    writer.write(obj.serviceDetails);
    writer.write(obj.contactNumbers);
    writer.write(obj.paymentMethod);
    writer.write(obj.paidAmount);
    writer.write(obj.date);
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Best Memories',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        fontFamily: 'Cairo',
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.purple[800],
          titleTextStyle: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('القائمة الرئيسية')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            _buildActionCard(
              context,
              'إضافة طلب جديد',
              Icons.add_circle,
              Colors.green,
              () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddOrderScreen()),
              ),
            ),
            _buildActionCard(
              context,
              'عرض الطلبات',
              Icons.list_alt,
              Colors.blue,
              () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ViewOrdersScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard(
      BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Icon(icon, color: color, size: 40),
        title: Text(title, style: TextStyle(fontSize: 20)),
        onTap: onTap,
      ),
    );
  }
}

class AddOrderScreen extends StatefulWidget {
  @override
  _AddOrderScreenState createState() => _AddOrderScreenState();
}

class _AddOrderScreenState extends State<AddOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _brideNameController = TextEditingController();
  final _priceController = TextEditingController();

  void _saveOrder() {
    if (_formKey.currentState!.validate()) {
      final box = Hive.box<WeddingOrder>('wedding_orders');
      final newOrder = WeddingOrder(
        brideName: _brideNameController.text,
        fatherName: "أب مجهول", // إضافة قيمة افتراضية
        surname: "غير معروف",
        price: double.parse(_priceController.text),
        serviceDetails: "خدمة افتراضية",
        contactNumbers: "123456789",
        paymentMethod: "نقدي",
        paidAmount: 0,
        date: DateTime.now(),
      );

      box.add(newOrder);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تمت إضافة الطلب بنجاح!')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إضافة طلب جديد')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _brideNameController,
                decoration: InputDecoration(labelText: 'اسم العروس'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              TextFormField(
                controller: _priceController,
                decoration: InputDecoration(labelText: 'السعر'),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _saveOrder, child: Text('حفظ الطلب')),
            ],
          ),
        ),
      ),
    );
  }
}